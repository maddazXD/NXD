// js/donate.js
// Donate system — notif HANYA di sidebar chat, bukan di layar video

import { db } from './firebase.js';
import { ref, push, onValue, set } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js";
import { escHTML, formatRp, showToast, spawnConfetti } from './ui.js';
import { icons } from './icons.js';

let lastDonateTs = 0; // Prevent duplicate notif on page load

export function initDonate() {
  renderDonateIcons();
  setupAmountChips();
  setupDonateForm();
  listenDonateNotif();
}

function renderDonateIcons() {
  const el = id => document.getElementById(id);
  if (el('donatePanelIcon')) el('donatePanelIcon').innerHTML = icons.donate;
}

// ── AMOUNT CHIPS ──────────────────────────────────────
let selectedAmount = 0;

function setupAmountChips() {
  const chips = document.querySelectorAll('.amount-chip');
  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      chips.forEach(c => c.classList.remove('selected'));
      chip.classList.add('selected');
      const val = parseInt(chip.dataset.amount || '0');
      selectedAmount = val;
      const input = document.getElementById('donateAmountInput');
      if (!input) return;
      if (val > 0) {
        input.value = val;
        input.readOnly = true;
      } else {
        input.value = '';
        input.readOnly = false;
        input.focus();
      }
    });
  });
}

// ── DONATE FORM ───────────────────────────────────────
function setupDonateForm() {
  const btn = document.getElementById('donateSubmitBtn');
  if (!btn) return;
  btn.addEventListener('click', handleDonateSubmit);
}

async function handleDonateSubmit() {
  const nameInput   = document.getElementById('donateNameInput');
  const amountInput = document.getElementById('donateAmountInput');
  const noteInput   = document.getElementById('donateNoteInput');
  const btn         = document.getElementById('donateSubmitBtn');

  const name   = nameInput?.value.trim() || 'Anonim';
  const amount = parseInt(amountInput?.value) || selectedAmount;
  const note   = noteInput?.value.trim() || '';

  // Validation
  if (!amount || amount < 1000) {
    showToast('Nominal minimal Rp 1.000');
    amountInput?.focus();
    return;
  }

  // Disable button prevent double submit
  btn.disabled = true;
  btn.textContent = 'Mengirim...';

  try {
    const payload = {
      type:   'donate_notif',
      name,
      amount,
      note,
      ts:     Date.now(),
    };

    // Push ke chat (akan ditampilkan sebagai donate alert di sidebar)
    await push(ref(db, 'chat/messages'), payload);

    // Trigger global notif signal (untuk confetti + banner di sidebar)
    await set(ref(db, 'stream/lastDonate'), payload);

    // Reset form
    if (nameInput)   nameInput.value   = '';
    if (amountInput) { amountInput.value = ''; amountInput.readOnly = false; }
    if (noteInput)   noteInput.value   = '';
    document.querySelectorAll('.amount-chip').forEach(c => c.classList.remove('selected'));
    selectedAmount = 0;

    showToast('Donasi terkirim! Namamu muncul di komentar semua penonton 🎉');

    // Switch ke tab chat supaya bisa lihat notif
    const chatTab = document.querySelector('.s-tab[data-tab="chat"]');
    chatTab?.click();

  } catch (err) {
    console.error(err);
    showToast('Gagal mengirim donasi. Coba lagi.');
  } finally {
    btn.disabled = false;
    btn.innerHTML = `${icons.donate || ''} Kirim Donasi`;
  }
}

// ── DONATE NOTIF LISTENER ─────────────────────────────
// Hanya menampilkan banner di sidebar + confetti
// TIDAK ada overlay/notif di layar video
function listenDonateNotif() {
  // Set initial timestamp so we don't trigger on page load
  lastDonateTs = Date.now();

  onValue(ref(db, 'stream/lastDonate'), snap => {
    const d = snap.val();
    if (!d || !d.ts) return;

    // Only show for NEW donations (after page load)
    if (d.ts <= lastDonateTs) return;
    lastDonateTs = d.ts;

    showDonateInSidebar(d);
    spawnConfetti();
  });
}

// Banner di dalam sidebar (di atas chat messages)
function showDonateInSidebar(d) {
  const banner = document.getElementById('donateSidebarBanner');
  if (!banner) return;

  banner.innerHTML = `
    <div style="display:flex;align-items:center;gap:10px">
      <div style="width:36px;height:36px;border-radius:50%;background:var(--gold-soft);border:1px solid rgba(245,158,11,.3);display:flex;align-items:center;justify-content:center;color:var(--gold);flex-shrink:0">
        ${icons.star || '★'}
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-family:'Outfit',sans-serif;font-size:16px;font-weight:800;color:var(--gold)">${formatRp(d.amount)}</div>
        <div style="font-size:12px;color:var(--text-2)">dari <b style="color:var(--text)">${escHTML(d.name)}</b></div>
      </div>
    </div>
    ${d.note ? `<div style="font-size:13px;color:var(--text-2);margin-top:8px;padding-left:46px;font-style:italic">"${escHTML(d.note)}"</div>` : ''}
  `;

  banner.style.cssText = `
    background: linear-gradient(135deg,rgba(245,158,11,.12),rgba(109,40,217,.1));
    border: 1px solid rgba(245,158,11,.4);
    border-radius: 12px; padding: 12px 14px; margin: 8px 12px 0;
    animation: msgIn .3s ease;
  `;
  banner.classList.remove('hidden');

  // Auto hide after 8 seconds
  clearTimeout(banner._hideTimer);
  banner._hideTimer = setTimeout(() => {
    banner.innerHTML = '';
    banner.style.cssText = '';
    banner.classList.add('hidden');
  }, 8000);
}
