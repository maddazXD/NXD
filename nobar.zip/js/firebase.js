// js/firebase.js
// ─────────────────────────────────────────────
// GANTI isi firebaseConfig di bawah ini
// dengan config dari project Firebase kamu.
// Cara dapat config:
// 1. Buka https://console.firebase.google.com
// 2. Buat project baru (gratis)
// 3. Tambah Web App
// 4. Copy firebaseConfig-nya ke sini
// 5. Di Firebase Console → Build → Realtime Database
//    → Create database → pilih mode "test" untuk awal
// ─────────────────────────────────────────────
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getDatabase } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-storage.js";

export const firebaseConfig = {
  apiKey:            "GANTI_API_KEY",
  authDomain:        "GANTI.firebaseapp.com",
  databaseURL:       "https://GANTI-default-rtdb.firebaseio.com",
  projectId:         "GANTI",
  storageBucket:     "GANTI.appspot.com",
  messagingSenderId: "GANTI",
  appId:             "GANTI"
};

const app = initializeApp(firebaseConfig);
export const db  = getDatabase(app);
export const storage = getStorage(app);
