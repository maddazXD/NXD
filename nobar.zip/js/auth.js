// js/auth.js
// Sistem login pakai UID khusus (nobarpildun000001aaaa)
// Daftar = bayar + upload bukti → host approve → sistem generate UID
import { db } from './firebase.js';
import {
  ref, set, get, push, onValue, serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js";
import { icons } from './icons.js';
import { showToast } from './ui.js';

// ── SESSION ──────────────────────────────────────────
const SESSION_KEY = 'nobar_session';

export function getSession() {
  try { return JSON.parse(localStorage.getItem(SESSION_KEY)); }
  catch { return null; }
}
export function saveSession(data) {
  localStorage.setItem(SESSION_KEY, JSON.stringify(data));
}
export function clearSession() {
  localStorage.removeItem(SESSION_KEY);
}

// ── GENERATE UID ─────────────────────────────────────
// Format: nobarpildun + 6 digit angka acak + 4 huruf acak
// Contoh: nobarpildun382710kxwp
function generateUID() {
  const digits = String(Math.floor(Math.random() * 1000000)).padStart(6, '0');
  const chars  = 'abcdefghijklmnopqrstuvwxyz';
  const letters = Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  return 'nobarpildun' + digits + letters;
}

async function generateUniqueUID() {
  let uid, exists = true;
  while (exists) {
    uid = generateUID();
    const snap = await get(ref(db, `uids/${uid}`));
    exists = snap.exists();
  }
  return uid;
}

// ── GATE PAGE CONTROLLER ──────────────────────────────
export function initGatePage() {
  const session = getSession();
  if (session) {
    checkAccessAndRedirect(session.accessUID);
    return;
  }

  // Setup tabs
  document.getElementById('tabLogin').addEventListener('click', () => switchGateTab('login'));
  document.getElementById('tabRegister').addEventListener('click', () => switchGateTab('register'));

  // Forms
  document.getElementById('loginForm').addEventListener('submit', handleLogin);
  document.getElementById('registerForm').addEventListener('submit', handleRegister);

  // Proof upload preview
  const proofInput = document.getElementById('proofFile');
  if (proofInput) {
    proofInput.addEventListener('change', e => {
      const file = e.target.files[0];
      if (!file) return;
      document.querySelector('.proof-upload .file-name').textContent = file.name;
      const reader = new FileReader();
      reader.onload = ev => {
        const img = document.getElementById('proofPreview');
        img.src = ev.target.result;
        img.classList.add('show');
      };
      reader.readAsDataURL(file);
    });
  }
}

function switchGateTab(tab) {
  document.getElementById('tabLogin').classList.toggle('active', tab === 'login');
  document.getElementById('tabRegister').classList.toggle('active', tab === 'register');
  document.getElementById('loginSection').classList.toggle('hidden', tab !== 'login');
  document.getElementById('registerSection').classList.toggle('hidden', tab !== 'register');
}

// ── REGISTER ─────────────────────────────────────────
async function handleRegister(e) {
  e.preventDefault();
  const name       = document.getElementById('regName').value.trim();
  const proofInput = document.getElementById('proofFile');
  const submitBtn  = document.getElementById('regSubmitBtn');

  clearErrors();
  let valid = true;

  if (!name)               { showError('regNameErr', 'Nama tidak boleh kosong'); valid = false; }
  if (!proofInput?.files[0]) { showError('proofErr', 'Upload bukti transfer dulu'); valid = false; }
  if (!valid) return;

  submitBtn.disabled = true;
  submitBtn.textContent = 'Mengirim...';

  try {
    // Convert proof to base64
    const proofBase64 = await fileToBase64(proofInput.files[0]);

    // Buat node pendaftar baru — belum punya UID, pakai push key sementara
    const pendingKey = 'reg_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);

    await set(ref(db, `pending/${pendingKey}`), {
      pendingKey,
      name,
      status: 'pending',     // pending | approved | rejected
      proofImage: proofBase64,
      createdAt: Date.now(),
    });

    // Simpan sesi sementara (pakai pendingKey, bukan accessUID)
    saveSession({ pendingKey, name, waitingApproval: true });
    showWaitingScreen(pendingKey);
    startStatusListenerPending(pendingKey);

  } catch (err) {
    console.error(err);
    showToast('Terjadi kesalahan. Coba lagi.');
    submitBtn.disabled = false;
    submitBtn.textContent = 'Kirim Bukti Transfer';
  }
}

// ── LOGIN DENGAN UID ──────────────────────────────────
async function handleLogin(e) {
  e.preventDefault();
  const uidInput  = document.getElementById('loginUID').value.trim().toLowerCase();
  const submitBtn = document.getElementById('loginSubmitBtn');

  clearErrors();

  if (!uidInput) { showError('loginUIDErr', 'Masukkan kode akses kamu'); return; }
  if (!uidInput.startsWith('nobarpildun')) {
    showError('loginUIDErr', 'Format kode akses tidak valid');
    return;
  }

  submitBtn.disabled = true;
  submitBtn.textContent = 'Memeriksa...';

  try {
    // Cek di index UID
    const uidSnap = await get(ref(db, `uids/${uidInput}`));
    if (!uidSnap.exists()) {
      showError('loginUIDErr', 'Kode akses tidak ditemukan');
      submitBtn.disabled = false; submitBtn.textContent = 'Masuk & Nonton';
      return;
    }

    const userRef = uidSnap.val(); // berisi userKey
    const userSnap = await get(ref(db, `users/${userRef}`));
    const user = userSnap.val();

    if (!user) {
      showError('loginUIDErr', 'Data akun tidak ditemukan');
      submitBtn.disabled = false; submitBtn.textContent = 'Masuk & Nonton';
      return;
    }

    if (user.status !== 'approved') {
      showError('loginUIDErr', 'Akun ini belum disetujui atau sudah ditolak host');
      submitBtn.disabled = false; submitBtn.textContent = 'Masuk & Nonton';
      return;
    }

    // Login berhasil
    saveSession({ accessUID: uidInput, userKey: userRef, name: user.name });
    window.location.href = 'watch.html';

  } catch (err) {
    console.error(err);
    showToast('Terjadi kesalahan. Coba lagi.');
    submitBtn.disabled = false; submitBtn.textContent = 'Masuk & Nonton';
  }
}

// ── STATUS CHECK (saat sudah ada sesi) ───────────────
async function checkAccessAndRedirect(accessUID) {
  if (!accessUID) { clearSession(); location.reload(); return; }

  const uidSnap = await get(ref(db, `uids/${accessUID}`));
  if (!uidSnap.exists()) { clearSession(); location.reload(); return; }

  const userKey  = uidSnap.val();
  const userSnap = await get(ref(db, `users/${userKey}`));
  const user = userSnap.val();

  if (!user) { clearSession(); location.reload(); return; }
  if (user.status === 'approved') { window.location.href = 'watch.html'; return; }
  if (user.status === 'rejected') { clearSession(); showError('loginUIDErr', 'Akun ditolak host.'); return; }
}

// Listener untuk pendaftar yang masih menunggu approval
function startStatusListenerPending(pendingKey) {
  onValue(ref(db, `pending/${pendingKey}/status`), snap => {
    const status = snap.val();
    if (status === 'approved') {
      // Host sudah approve dan sistem assign UID — ambil accessUID
      get(ref(db, `pending/${pendingKey}/accessUID`)).then(s => {
        const uid = s.val();
        if (uid) {
          get(ref(db, `uids/${uid}`)).then(us => {
            const userKey = us.val();
            get(ref(db, `users/${userKey}/name`)).then(ns => {
              saveSession({ accessUID: uid, userKey, name: ns.val() });
              showUIDRevealScreen(uid);
            });
          });
        }
      });
    } else if (status === 'rejected') {
      clearSession();
      showToast('Pembayaran ditolak host. Silakan coba lagi atau hubungi host.');
      location.reload();
    }
  });
}

// ── WAITING SCREEN ────────────────────────────────────
function showWaitingScreen(pendingKey) {
  const card = document.querySelector('.gate-card');
  if (!card) return;
  card.innerHTML = `
    <div class="gate-waiting">
      <div class="waiting-spinner"></div>
      <div class="waiting-title">Menunggu Konfirmasi Pembayaran</div>
      <div class="waiting-sub">
        Bukti transfer kamu sudah dikirim.<br>
        Host akan mengkonfirmasi pembayaranmu.<br>
        <b>Kode akses kamu akan muncul otomatis setelah disetujui.</b>
      </div>
      <div class="status-badge status-pending" style="margin-top:8px">
        ${icons.clock || ''} Sedang Ditinjau
      </div>
    </div>
  `;
}

// ── LAYAR TAMPIL UID SETELAH APPROVE ─────────────────
function showUIDRevealScreen(uid) {
  const card = document.querySelector('.gate-card');
  if (!card) return;
  card.innerHTML = `
    <div class="gate-waiting" style="gap:14px">
      <div style="font-size:40px">🎉</div>
      <div class="waiting-title" style="color:var(--green)">Pembayaran Disetujui!</div>
      <div class="waiting-sub">
        Ini adalah <b>Kode Akses</b> unik milik kamu.<br>
        Simpan dan jangan bagikan ke orang lain!
      </div>

      <div style="background:var(--bg-2);border:1.5px solid var(--gold);border-radius:12px;padding:16px 18px;width:100%;box-sizing:border-box">
        <div style="font-size:11px;color:var(--text-2);margin-bottom:6px;letter-spacing:.04em;text-transform:uppercase">Kode Akses Kamu</div>
        <div id="uidDisplay" style="font-family:monospace;font-size:16px;font-weight:700;color:var(--gold);word-break:break-all;letter-spacing:.06em">${escHTML(uid)}</div>
      </div>

      <button id="copyUIDBtn" class="btn btn-gold w-full" style="margin-top:4px">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
        Salin Kode Akses
      </button>

      <button id="enterWatchBtn" class="btn btn-primary w-full">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 10 4 15 9 20"/><path d="M20 4v7a4 4 0 0 1-4 4H4"/></svg>
        Masuk & Nonton Sekarang
      </button>

      <div style="font-size:11px;color:var(--text-2);text-align:center;margin-top:4px">
        ⚠️ Screenshot atau catat kode ini. Kamu butuhkan untuk login berikutnya.
      </div>
    </div>
  `;

  document.getElementById('copyUIDBtn').addEventListener('click', () => {
    navigator.clipboard.writeText(uid).then(() => {
      showToast('Kode akses tersalin!');
      document.getElementById('copyUIDBtn').textContent = '✓ Tersalin!';
    }).catch(() => showToast('Gagal menyalin. Salin manual: ' + uid));
  });

  document.getElementById('enterWatchBtn').addEventListener('click', () => {
    window.location.href = 'watch.html';
  });
}

// ── ADMIN / HOST: Approve/Reject di watch.html ────────
export async function loadPendingUsers(containerId) {
  onValue(ref(db, 'pending'), snap => {
    const pending_all = snap.val() || {};
    const pendingList = Object.values(pending_all).filter(u => u.status === 'pending');

    onValue(ref(db, 'users'), snap2 => {
      const users = snap2.val() || {};
      const approvedList = Object.values(users).filter(u => u.status === 'approved');
      const el = document.getElementById(containerId);
      if (!el) return;

      el.innerHTML = `
        <div style="font-size:12px;color:var(--text-2);margin-bottom:10px">
          ${icons.users} Menunggu: <b style="color:var(--gold)">${pendingList.length}</b> &nbsp;|&nbsp; Disetujui: <b style="color:var(--green)">${approvedList.length}</b>
        </div>
      `;

      if (pendingList.length === 0) {
        el.innerHTML += `<div class="sys-msg" style="padding:12px 0">Tidak ada pendaftar baru.</div>`;
        return;
      }

      pendingList.forEach(u => {
        const row = document.createElement('div');
        row.style.cssText = 'background:var(--bg-2);border:1px solid var(--border);border-radius:10px;padding:12px;margin-bottom:8px';
        row.innerHTML = `
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
            <div class="avatar" style="background:var(--accent);width:28px;height:28px;font-size:11px">${u.name[0].toUpperCase()}</div>
            <div style="flex:1;min-width:0">
              <div style="font-weight:600;font-size:13px">${escHTML(u.name)}</div>
              <div style="font-size:11px;color:var(--text-2)">Belum punya kode akses</div>
            </div>
            <span class="status-badge status-pending">Pending</span>
          </div>
          ${u.proofImage ? `<img src="${u.proofImage}" style="width:100%;border-radius:8px;max-height:100px;object-fit:cover;margin-bottom:8px" alt="Bukti">` : ''}
          <div style="display:flex;gap:6px">
            <button onclick="approveUser('${u.pendingKey}')" class="btn btn-sm" style="background:var(--green-soft);border-color:rgba(34,197,94,.3);color:var(--green);flex:1">
              ${icons.check} Setujui
            </button>
            <button onclick="rejectUser('${u.pendingKey}')" class="btn btn-sm btn-danger" style="flex:1">
              ${icons.x} Tolak
            </button>
          </div>
        `;
        el.appendChild(row);
      });
    }, { onlyOnce: true });
  });
}

// Host approve: generate UID unik → simpan user → update pending
export async function approveUser(pendingKey) {
  try {
    const snap = await get(ref(db, `pending/${pendingKey}`));
    const pending = snap.val();
    if (!pending) { showToast('Data tidak ditemukan.'); return; }

    // Generate UID unik
    const accessUID = await generateUniqueUID();

    // Buat entry user resmi
    const userKey = 'user_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
    await set(ref(db, `users/${userKey}`), {
      userKey,
      name: pending.name,
      accessUID,
      status: 'approved',
      createdAt: Date.now(),
      approvedAt: Date.now(),
    });

    // Daftarkan UID ke index (untuk lookup cepat saat login)
    await set(ref(db, `uids/${accessUID}`), userKey);

    // Update pending record → trigger listener di client
    await set(ref(db, `pending/${pendingKey}/status`), 'approved');
    await set(ref(db, `pending/${pendingKey}/accessUID`), accessUID);

    showToast(`User disetujui! UID: ${accessUID}`);
  } catch (err) {
    console.error(err);
    showToast('Gagal menyetujui. Coba lagi.');
  }
}

export async function rejectUser(pendingKey) {
  await set(ref(db, `pending/${pendingKey}/status`), 'rejected');
  showToast('Pendaftaran ditolak.');
}

// Expose globally untuk onclick di HTML dinamis
window.approveUser = approveUser;
window.rejectUser  = rejectUser;

// ── HELPERS ───────────────────────────────────────────
function fileToBase64(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = () => rej(new Error('Read failed'));
    r.readAsDataURL(file);
  });
}

function showError(id, msg) {
  const el = document.getElementById(id);
  if (el) { el.textContent = msg; el.classList.add('show'); }
}

function clearErrors() {
  document.querySelectorAll('.form-error').forEach(el => el.classList.remove('show'));
}

export function escHTML(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
