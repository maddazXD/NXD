# NobarXD — Setup Guide

Website nonton bareng realtime dengan sistem donate, komentar, like, dan payment gate.

---

## Struktur File

```
nobar/
├── index.html        ← Halaman login/daftar + bayar
├── watch.html        ← Halaman nonton utama
├── css/
│   ├── base.css      ← Variables, reset, komponen bersama
│   ├── gate.css      ← Styling halaman login/daftar
│   └── watch.css     ← Styling halaman nonton + responsive
└── js/
    ├── firebase.js   ← Config Firebase (WAJIB DIISI)
    ├── icons.js      ← Semua icon SVG
    ├── auth.js       ← Login, register, payment gate
    ├── player.js     ← Sinkronisasi video
    ├── chat.js       ← Komentar realtime
    ├── donate.js     ← Sistem donate + notif di sidebar
    └── ui.js         ← Toast, landscape mode, utilities
```

---

## Setup Firebase (WAJIB)

### 1. Buat Project Firebase
1. Buka https://console.firebase.google.com
2. Klik **Add Project** → beri nama (misal: `nobarxd`)
3. Disable Google Analytics (opsional) → **Create Project**

### 2. Aktifkan Realtime Database
1. Di sidebar kiri → **Build** → **Realtime Database**
2. Klik **Create Database**
3. Pilih region terdekat (Singapore disarankan)
4. Pilih **Start in test mode** → Next → Done

### 3. Atur Rules Database
Di Realtime Database → tab **Rules**, paste ini:
```json
{
  "rules": {
    "stream": {
      ".read": true,
      ".write": true
    },
    "chat": {
      ".read": true,
      ".write": true
    },
    "users": {
      ".read": true,
      ".write": true
    }
  }
}
```
Klik **Publish**.

### 4. Ambil Config Firebase
1. Di Firebase Console → klik ikon gear ⚙️ → **Project Settings**
2. Scroll ke bawah → **Your apps** → klik ikon `</>`  (Web)
3. Daftarkan app → Copy isi `firebaseConfig`
4. Buka `js/firebase.js` → paste config kamu

### 5. Ganti Password Host
Buka `js/player.js` → cari baris:
```js
const HOST_PASSWORD = 'HOST_PASS_GANTI_INI';
```
Ganti dengan password yang kamu mau.

---

## Deploy (Gratis)

### Opsi A — GitHub Pages
1. Upload semua file ke repo GitHub
2. Settings → Pages → Source: main branch → Save
3. Link: `https://username.github.io/nobar`

### Opsi B — Netlify (Drag & Drop)
1. Buka https://netlify.com → Log in
2. Drag folder `nobar/` ke dashboard Netlify
3. Selesai! Link langsung tersedia

### Opsi C — Vercel
```bash
npx vercel --prod
```

---

## Cara Pakai

### Sebagai Host
1. Buka `watch.html`
2. Klik tombol ⚙️ di pojok kanan atas
3. Masukkan password host
4. Panel kontrol muncul:
   - **Load Video**: paste URL film `.mp4` atau stream
   - **Set Judul**: nama film yang tampil ke semua viewer
   - **Play/Pause/Sync/Stop**: kontrol pemutaran
   - **Rekening**: isi info rekening untuk donate
   - **Users**: setujui/tolak pendaftar

### Sebagai Viewer
1. Buka `index.html`
2. Pilih **Daftar + Bayar**
3. Isi nama, email, password
4. Transfer Rp 1.000 ke rekening host
5. Upload screenshot bukti transfer
6. Tunggu host menyetujui → halaman nonton terbuka otomatis

### Fitur Donate
1. Di halaman nonton → klik tab **Donate**
2. Pilih nominal
3. Isi nama + pesan opsional
4. Transfer ke rekening yang tertera
5. Klik **Kirim Donasi** → nama + pesan muncul di sidebar semua penonton

---

## Tips URL Video

- File MP4 langsung: `https://example.com/film.mp4`
- Google Drive: ubah link jadi direct download
- Archive.org: link langsung ke file
- Atau hosting sendiri di Cloudflare R2 (gratis 10GB)

---

Dibuat oleh MaddazXD · NobarXD 2024
